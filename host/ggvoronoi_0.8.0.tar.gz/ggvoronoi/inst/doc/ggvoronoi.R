## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(ggvoronoi)
library(ggplot2)

## ----1a------------------------------------------------------------------
library(ggvoronoi)
library(ggplot2)

ggplot(points)+
  geom_point(aes(x,y,color=fill))

## ----1b------------------------------------------------------------------
ggplot(points)+
  geom_voronoi(aes(x,y,fill=fill))

## ----1c------------------------------------------------------------------
ggplot(points,aes(x,y))+
  stat_voronoi(geom="path")+
  geom_point()

## ----1d------------------------------------------------------------------
ggplot(data=points, aes(x=x, y=y, fill=fill)) + 
  geom_voronoi(outline = circle)

## ----1e------------------------------------------------------------------
ggplot(points,aes(x,y))+
  geom_voronoi(aes(fill=fill),outline=circle,color="#4dffb8",size=.125)+
  scale_fill_gradient(low="#4dffb8",high="black",guide=F)+
  theme_void()+
  coord_fixed()

