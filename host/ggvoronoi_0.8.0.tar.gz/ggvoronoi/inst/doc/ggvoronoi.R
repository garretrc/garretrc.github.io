## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----1a------------------------------------------------------------------
library(ggvoronoi)
set.seed(45056)
x = sample(1:200,100)
y = sample(1:200,100)
points = data.frame(x, y,
                    distance = sqrt((x-100)^2 + (y-100)^2))
circle = data.frame(x = 100*(1+cos(seq(0, 2*pi, length.out = 2500))),
                    y = 100*(1+sin(seq(0, 2*pi, length.out = 2500))),
                    group = rep(1,2500))

ggplot(points)+
  geom_point(aes(x,y,color=distance))+
  geom_path(data=circle,aes(x,y,group=group))

## ----1b------------------------------------------------------------------
ggplot(points)+
  geom_voronoi(aes(x,y,fill=distance))

## ----1c------------------------------------------------------------------
ggplot(points,aes(x,y))+
  stat_voronoi(geom="path")+
  geom_point()

## ----1d------------------------------------------------------------------
ggplot(data=points, aes(x=x, y=y, fill=distance)) + 
  geom_voronoi(outline = circle)

## ----1e------------------------------------------------------------------
ggplot(points,aes(x,y))+
  geom_voronoi(aes(fill=distance),outline=circle,
               color="#4dffb8",size=.125)+
  scale_fill_gradient(low="#4dffb8",high="black",guide=F)+
  theme_void()+
  coord_fixed()

## ----2a,message=F--------------------------------------------------------
library(ggmap)

ox_map = get_map(location = c(-84.7398373,39.507306),zoom = 15)
bounds = as.numeric(attr(ox_map,"bb"))

map=
  ggmap(ox_map,base_layer = ggplot(data=oxford_bikes,aes(x,y)))+ #map of oxford
        xlim(-85,-84)+ylim(39,40)+                               #adjust plot limits
        coord_map(ylim=bounds[c(1,3)],xlim=bounds[c(2,4)])       #adjust plot zoom

## ----2b------------------------------------------------------------------
map + geom_path(stat="voronoi",alpha=.085,size=1)+
      geom_point(color="blue",size=.9)

