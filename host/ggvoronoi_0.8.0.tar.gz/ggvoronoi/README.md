# ggvoronoi
Easy Voronoi choropleth maps with ggplot2
